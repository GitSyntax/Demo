sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller,Filter,FilterOperator) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.Customers", {

    onInit: function () {
      
      this.getOwnerComponent()
          .getRouter()
          .getRoute("customers")
          .attachMatched(this._onRouteMatched, this);
    },
    onFilterCustomers(oEvent) {
			// build filter array
			const aFilter = [];
			const sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("Name", FilterOperator.Contains, sQuery));
			}

			// filter binding
			const oList = this.byId("customers");
			const oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},

    _onRouteMatched: function () {
      console.log("Customers loaded");
      
    }
  });
});