sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller,Filter,FilterOperator) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.Reports", {
    onInit: function () {
      this.getOwnerComponent()
          .getRouter()
          .getRoute("report")
          .attachMatched(this._onRouteMatched, this);
    },

    onFilterReports(oEvent) {
			// build filter array
			const aFilter = [];
			const sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("productName", FilterOperator.Contains, sQuery));
			}

			// filter binding
			const oList = this.byId("report");
			const oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},


    _onRouteMatched: function () {
      console.log("Reports page loaded");
    }
  });
});