sap.ui.define([
  "sap/ui/core/mvc/Controller"
], function (Controller) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.Dashboard", {

    onInit: function () {
      
      //filter for top quantity sold data in sales in dashboard page
    
       var oModel = new sap.ui.model.json.JSONModel();

    oModel.loadData("model/sales.json");

    // Sort AFTER data is loaded
    oModel.attachRequestCompleted(function () {
        var oData = oModel.getData();

        oData.Sales.sort(function (a, b) {
            return b.quantitySold - a.quantitySold;
        });

        oModel.setData(oData);
    });

    this.getView().setModel(oModel, "sales");
    },

    _onRouteMatched: function () {
      console.log("Dashboard loaded");
      
    }
  });
});