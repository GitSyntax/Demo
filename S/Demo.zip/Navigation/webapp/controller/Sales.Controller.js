sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller,Filter,FilterOperator) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.Sales", {

    onInit: function () {
      // Attach route — fires every time Dashboard is navigated to
      this.getOwnerComponent()
          .getRouter()
          .getRoute("sales")
          .attachMatched(this._onRouteMatched, this);
    },

    _onRouteMatched: function () {
      console.log("Sales loaded");
    }
  });
});