sap.ui.define([
  "sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller,Filter,FilterOperator) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.Products", {
    onInit: function () {
    
      this.getOwnerComponent()
          .getRouter()
          .getRoute("products")
          .attachMatched(this._onRouteMatched, this);
    },

    onFilterProducts(oEvent) {
			// build filter array
			const aFilter = [];
			const sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("Name", FilterOperator.Contains, sQuery));
			}

			// filter binding
			const oList = this.byId("products");
			const oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},





    onGoToChart: function () {
  this.byId("navContainer").to(this.byId("chartPage"));
},

onGoToTable: function () {
  this.byId("navContainer").back();
},

onMeasureChange: function (oEvent) {
  var sKey = oEvent.getSource().getSelectedKey();
  var oPieChart = this.byId("pieChart");
  var oOldFeed = oPieChart.getFeedsByUID("size")[0];

  oPieChart.removeFeed(oOldFeed);

  oPieChart.addFeed(new sap.viz.ui5.controls.common.feeds.FeedItem({
    uid   : "size",
    type  : "Measure",
    values: [sKey]
  }));
},






    _onRouteMatched: function () {
      console.log("Product page loaded");
      
    }
  });
});