sap.ui.define([
  "sap/ui/core/mvc/Controller"
], function (Controller) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.App", {

    onInit: function () {
      
    },

    // Fired when any sidebar item is clicked
    onNavItemSelect: function (oEvent) {
      // Step 1: Get the key of the clicked nav item
      var sKey = oEvent.getParameter("item").getKey();

      // Step 2: Get the router from the component
      var oRouter = this.getOwnerComponent().getRouter();

      // Step 3: Navigate to the matching route by key
      oRouter.navTo(sKey);
      // "home"      → triggers route pattern ""
      // "dashboard" → triggers route pattern "dashboard"
    },

    // Toggle sidebar expand/collapse
    onToggleSidebar: function () {
      var oToolPage = this.byId("toolPage");
      oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
    }

  });
});

// sap.ui.define([
//   "sap/ui/core/mvc/Controller"
// ], function (Controller) {
//   "use strict";

//   return Controller.extend("ui5.walkthrough.controller.App", {
//     onInit: function () {
//       console.log("App Loaded");
//     }
//   });
// });


// sap.ui.define([
//   "sap/ui/core/mvc/Controller"
// ], function (Controller) {
//   "use strict";

//   return Controller.extend("ui5.walkthrough.controller.App", {

//     onInit: function () {
//       this.oRouter = this.getOwnerComponent().getRouter();
//     },

//     onNavItemSelect: function (oEvent) {
//       const oItem = oEvent.getParameter("item");
//       const sKey = oItem.getKey();

//       this.oRouter.navTo(sKey);
//     }

//   });
// });

// sap.ui.define([
//   "sap/ui/core/mvc/Controller"
// ], function (Controller) {
//   "use strict";

//   return Controller.extend("ui5.walkthrough.controller.App", {
//     onInit: function () {
//       console.log("App Loaded");
//     }
//   });
// });