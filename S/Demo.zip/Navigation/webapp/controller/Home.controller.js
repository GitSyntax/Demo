sap.ui.define([
  "sap/ui/core/mvc/Controller"
], function (Controller) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.Home", {
    onInit: function () {
      // Attach route matched — fires every time Home is navigated to
      this.getOwnerComponent()
          .getRouter()
          .getRoute("home")
          .attachMatched(this._onRouteMatched, this);
    },

    _onRouteMatched: function () {
      console.log("Home page loaded");
      
    }
  });
});