sap.ui.define([
  "sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller,Filter,FilterOperator) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.Warehouse", {

    onInit: function () {
      
      this.getOwnerComponent()
          .getRouter()
          .getRoute("warehouse")
          .attachMatched(this._onRouteMatched, this);
    },

     onFilterWarehouses(oEvent) {
			
			const aFilter = [];
			const sQuery = oEvent.getParameter("query");
			if (sQuery) {
    var oFilter = new Filter({
        filters: [
            new Filter("warehouseName", FilterOperator.Contains, sQuery),
            new Filter("itemName", FilterOperator.Contains, sQuery)
        ],
        and: false 
    });

    aFilter.push(oFilter);
}

			
			const oList = this.byId("warehouses");
			const oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},

    _onRouteMatched: function () {
      console.log("Warehouse loaded");
      
    }
  });
});