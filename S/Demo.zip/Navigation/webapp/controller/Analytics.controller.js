sap.ui.define([
  "sap/ui/core/mvc/Controller"
], function (Controller) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.Analytics", {

    onInit: function () {
      
      this.getOwnerComponent()
          .getRouter()
          .getRoute("analytics")
          .attachMatched(this._onRouteMatched, this);
    },
//graph purpose

onAfterRendering: function () {
    var oVizFrame = this.getView().byId("productChart");
    if (!oVizFrame) return;

    oVizFrame.setVizProperties({
        plotArea: {
            dataShape: {
                primaryAxis: ["bar"],
                secondaryAxis: ["line"]
            },
            dataLabel: { visible: false },
            marker: { visible: true, size: 8 }
        },
        valueAxis:  { title: { visible: true, text: "Price (Rs.)" } },
        valueAxis2: { title: { visible: true, text: "Rating" } },
        categoryAxis: { title: { visible: true, text: "Product" } },
        title: { visible: true, text: "Products — Price vs Rating" }
    });

    var oPopover = new sap.viz.ui5.controls.Popover({});
    oPopover.connect(oVizFrame.getVizUid());
},
    _onRouteMatched: function () {
      console.log("Analytics loaded");
      
    }
  });
});