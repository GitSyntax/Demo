sap.ui.define([
  "sap/ui/core/mvc/Controller",
   "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller,Filter,FilterOperator) {
  "use strict";

  return Controller.extend("ui5.walkthrough.controller.Transactions", {
    onInit: function () {
      
      this.getOwnerComponent()
          .getRouter()
          .getRoute("transaction")
          .attachMatched(this._onRouteMatched, this);
    },

    onFilterTransactions(oEvent) {
		
			const aFilter = [];
			const sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("productName", FilterOperator.Contains, sQuery));
			}

			
			const oList = this.byId("transaction");
			const oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},


    _onRouteMatched: function () {
      console.log("Transactions page loaded");
      
    }
  });
});