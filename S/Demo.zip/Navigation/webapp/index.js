sap.ui.define([
  "sap/ui/core/mvc/XMLView"
], (XMLView) => {
  "use strict";

  console.log("Index loaded");

  XMLView.create({
    viewName: "ui5.walkthrough.view.App"
  }).then((oView) => {
    console.log("View loaded");
    oView.placeAt("content");
  }).catch((err) => {
    console.error("ERROR:", err);
  });
});