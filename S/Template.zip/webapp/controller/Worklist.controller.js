/*global location history */
sap.ui.define([
	"com/Template/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/Template/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";
	var that;
	var oAppCtx;

	return BaseController.extend("com.Template.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			sap.ui.core.BusyIndicator.show();
			var oMode = {
				"OverviewRequestor": false,
				"OverviewApproval": false
			};

			var sMode = new sap.ui.model.json.JSONModel(oMode);
			this.getView().setModel(sMode, "sMode");

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			if (oRouter.getRoute("worklist")) {
				oRouter.getRoute("worklist").attachPatternMatched(this._onObjectMatched, this);
			}
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */
		_onObjectMatched: function() {
			sap.ui.getCore().AppContext = undefined;
			oAppCtx = sap.ui.getCore().AppContext;
			if (!oAppCtx) {
				sap.ui.getCore().AppContext = new Object();
				oAppCtx = sap.ui.getCore().AppContext;
			}
			var oHashObject = new sap.ui.core.routing.HashChanger();
			var sHash = oHashObject.getHash();

		},
	});
});