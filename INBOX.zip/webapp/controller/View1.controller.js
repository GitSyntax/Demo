// sap.ui.define([
// 	"sap/ui/core/mvc/Controller"
// ], function(Controller) {
// 	"use strict";

// 	return Controller.extend("com.MM_INBOX.controller.View1", {
// 		onInit: function() {

// 			// this.getRouter().getRoute("View1").attachPatternMatched(this._onObjectMatched, this);
// 			this.getOwnerComponent().getRouter().getRoute("View1").attachPatternMatched(this._onRouteMatched, this);
// 		},

// 		_onRouteMatched: function(oEvent) {
// 		debugger
// 			var sReq = oEvent.getParameter("arguments");

// 		},
// 	});
// });

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"sap/ui/core/syncStyleClass",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/suite/ui/commons/library",
	"sap/ushell/Container",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(
	Controller,
	Device,
	Fragment,
	syncStyleClass,
	Filter,
	FilterOperator,
	MessageBox,
	MessageToast,
	JSONModel,
	suiteLibrary,
	ShellContainer,
	Filter2,
	FilterOperator2
) {
	"use strict";
	return Controller.extend("com.MM_INBOX.controller.View1", {
		onInit: function() {
			this.getOwnerComponent().getRouter()
				.getRoute("View1")
				.attachPatternMatched(this._onRouteMatched, this);
		},

		_onRouteMatched: function(oEvent) {
			debugger
			if (oEvent.getParameter("arguments").InstanceID) {
				var sInstanceId = oEvent.getParameter("arguments").InstanceID;
			}
		}
	});
});