/*global location history */
sap.ui.define([
	"com/MANAGE_QUOTATION/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/MANAGE_QUOTATION/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";
	var that;
	var oAppCtx;

	return BaseController.extend("com.MANAGE_QUOTATION.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			sap.ui.core.BusyIndicator.hide();
			var oMode = {
				"OverviewRequestor": false,
				"OverviewApproval": false
			};

			var sMode = new sap.ui.model.json.JSONModel(oMode);
			this.getView().setModel(sMode, "sMode");

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			if (oRouter.getRoute("worklist")) {
				oRouter.getRoute("worklist").attachPatternMatched(this._onObjectMatched, this);
			}
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		onSideNavButtonPress: function() {
			var oToolPage = this.byId("toolPage");
			oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
		},
		// onVendorCreationHandle: function(oEvent) {
		// 	sap.ui.core.BusyIndicator.show();
		// 	var oNavContainer = this.getView().byId("navCon");
		// 	var oVendorPage = oNavContainer.getPages().find(function(page) {
		// 		return page.getId().endsWith("idVednorPage");
		// 	});

		// 	if (oVendorPage) {
		// 		var oVendorController = oVendorPage.getContent()[0].getController();
		// 		if (oVendorController) {
		// 			oVendorController.onCreateVendorHandle();
		// 		}
		// 	}
		// 	oNavContainer.to(oVendorPage);
		// },
		onSideNavigationItemSelect: function(oEvent) {
			let sKey = oEvent.getParameter("item").getKey(),
				oNavCon = this.byId("navCon"),
				animation = "baseSlide";
			if (sKey === "idManagePage") {
				let oManagePage = this.byId("idManagePage");
				oManagePage.destroyContent();
				let oNewView = sap.ui.view({
					viewName: "com.MANAGE_QUOTATION.view.Manage",
					type: sap.ui.core.mvc.ViewType.XML
				});
				oManagePage.addContent(oNewView);
				let oManageController = oManagePage.getContent()[0].getController();
				if (oManageController && oManageController._getOninit) {
					oManageController._getOninit();
				}
			} else if (sKey === "idUploadPage") {
				let oUploadPage = this.byId("idUploadPage");
				oUploadPage.destroyContent();
				let oNewView = sap.ui.view({
					viewName: "com.MANAGE_QUOTATION.view.Upload",
					type: sap.ui.core.mvc.ViewType.XML
				});
				oUploadPage.addContent(oNewView);
				let oUploadController = oUploadPage.getContent()[0].getController();
				if (oUploadController && oUploadController._getOninit) {
					oCreateRequestController._getOninit();
				}
			} else if (sKey === "idBENPage") {
				let oNegotiationPage = this.byId("idBENPage");
				oNegotiationPage.destroyContent();
				let oNewView = sap.ui.view({
					viewName: "com.MANAGE_QUOTATION.view.Negotiation",
					type: sap.ui.core.mvc.ViewType.XML
				});
				oNegotiationPage.addContent(oNewView);
				let oNegotiationController = oNegotiationPage.getContent()[0].getController();
				if (oNegotiationController && oNegotiationController._getOninit) {
					oNegotiationController._getOninit();
				}
			} else if (sKey === "idVoucherPage") {
				let oVoucherPage = this.byId("idVoucherPage");
				oVoucherPage.destroyContent();
				let oNewView = sap.ui.view({
					viewName: "com.MANAGE_QUOTATION.view.Voucher",
					type: sap.ui.core.mvc.ViewType.XML
				});
				oVoucherPage.addContent(oNewView);
				let oVoucherontroller = oVoucherPage.getContent()[0].getController();
				if (oVoucherontroller && oVoucherontroller._getOninit) {
					oVoucherontroller._getOninit();
				}
			}
			oNavCon.to(this.byId(sKey), animation);
		},
		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */
		_onObjectMatched: function() {
			sap.ui.getCore().AppContext = undefined;
			oAppCtx = sap.ui.getCore().AppContext;
			if (!oAppCtx) {
				sap.ui.getCore().AppContext = new Object();
				oAppCtx = sap.ui.getCore().AppContext;
			}
			var oHashObject = new sap.ui.core.routing.HashChanger();
			var sHash = oHashObject.getHash();

		},
	});
});