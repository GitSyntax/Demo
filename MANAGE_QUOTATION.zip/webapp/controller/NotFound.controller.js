sap.ui.define([
		"com/MANAGE_QUOTATION/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("com.MANAGE_QUOTATION.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);